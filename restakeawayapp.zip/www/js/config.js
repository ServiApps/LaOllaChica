
var krms_config ={	
	'ApiUrl':"http://restakeaway.com/mobileapp/api",
	'DialogDefaultTitle':"Restakeaway",
	'pushNotificationSenderid':"AIzaSyD0bAIb6Lvvd-axKaiAj8aEnWtUclbPsds",
	'facebookAppId':"YOUR_FACEBOOK_APP_ID"
};